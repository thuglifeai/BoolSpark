# BoolSpark Design Guidelines

## Design Approach
**System**: Material Design 3 with custom tech-forward adaptations
**Rationale**: Productivity tool requiring clarity, efficiency, and data density with modern polish

## Color System

### Light Mode
- **Primary Purple**: 258 80% 58% (brand identity, CTAs, active states)
- **Primary Cyan**: 187 95% 43% (accents, success states, highlights)
- **Background**: 0 0% 99% (main canvas)
- **Surface**: 0 0% 100% (cards, modals)
- **Surface Variant**: 258 15% 96% (subtle containers)
- **Text Primary**: 240 10% 10%
- **Text Secondary**: 240 5% 45%
- **Border**: 240 6% 90%

### Dark Mode
- **Primary Purple**: 258 85% 70% (boosted luminosity)
- **Primary Cyan**: 187 90% 55% (boosted luminosity)
- **Background**: 240 10% 8% (deep base)
- **Surface**: 240 8% 12% (elevated cards)
- **Surface Variant**: 258 12% 16% (subtle containers)
- **Text Primary**: 0 0% 98%
- **Text Secondary**: 240 5% 70%
- **Border**: 240 5% 22%

## Typography
- **Headings**: Inter (700/600 weight), sizes: 32px/24px/20px/18px
- **Body**: Inter (400/500 weight), 16px/14px
- **Code/Boolean**: JetBrains Mono (400/500), 14px/13px
- **Labels**: Inter (500), 13px uppercase, 0.5px letter-spacing

## Layout System
**Spacing Units**: Consistently use 4, 8, 12, 16, 24, 32, 48, 64 (tailwind: p-1, p-2, p-3, p-4, p-6, p-8, p-12, p-16)

## Core Components

### Boolean String Display (Centerpiece)
- Large card (w-full, rounded-2xl) with gradient border (purple to cyan, 2px)
- Monaco/JetBrains Mono font display with syntax highlighting
- Keyword highlighting: operators (cyan), values (purple tint), quotes (neutral)
- Action bar (top-right): Copy (icon+text), Share (icon+text), Download (icon+text), **Refresh** (icon, purple background, white icon)
- Micro-animation: Refresh button rotates 360° on click (0.5s)
- Character count badge (bottom-right, small, surface variant background)

### File Upload Zone
- Dashed border (3px, cyan when active/hover, border color default)
- 160px height, center-aligned icon (document, 48px) + text
- Drag overlay: full card overlay, purple gradient background (20% opacity), "Drop to analyze" text
- Accepted formats badge below: "Supports .pdf, .docx, .txt"

### History Panel (Left Sidebar, 320px)
- Scrollable list, grouped by date ("Today", "Yesterday", "Last 7 Days")
- Each item: truncated boolean preview (2 lines), timestamp, quick copy icon
- Hover: expand preview on purple-tinted background
- Selected state: cyan left border (4px), subtle surface variant background

### Analytics Dashboard
- 4-metric grid (2×2 on desktop, stacked mobile):
  - Total Searches (cyan icon, large number)
  - Avg String Length (purple icon, metric + trend arrow)
  - Most Used Operators (chart icon, top 3 list)
  - Success Rate (percentage ring chart, purple/cyan segments)
- Card style: subtle shadow, rounded-xl, padding-6

### Navigation
- Top bar (sticky): Logo (purple/cyan gradient text), Search (global, subtle), Profile/Settings (right)
- Quick actions (floating bottom-right): Generate New (purple FAB, 64px), History Toggle (smaller FAB below, cyan outline)

### Refresh Button Integration
- **Location**: Top-right of Boolean String Display card, inline with Copy/Share/Download
- **Style**: Filled purple button (same height as other actions), white refresh icon (rotating arrows)
- **States**: Default (purple), Hover (darker purple), Loading (rotating animation + "Regenerating..." text replacement)
- **Spacing**: 12px gap from other actions

## Interactions & Animations
- **Card Reveals**: Stagger animation (0.1s delay between cards) on load
- **Boolean Generate**: Shimmer effect across display area (1s), then fade-in result
- **Copy Success**: Checkmark icon replacement (0.3s), cyan pulse on card border
- **Refresh**: Icon rotates, display blurs (backdrop-filter), new string fades in
- **Dark Mode Toggle**: Smooth color transition (0.4s ease-in-out), no layout shift

## Images

### Application Interface
**No hero image needed** - this is a utility-focused dashboard application. Use gradient backgrounds and iconography instead.

### Marketing/Landing Page (if needed)
- **Hero Section**: Abstract illustration of Boolean logic flow (nodes, connections, search operators floating) with purple/cyan gradient overlay (1200×600px, centered)
- **Feature Screenshots**: Actual app interface screenshots with subtle shadow/border treatment
- **Use Case Images**: Recruiter workspace photos (diverse, professional, using laptop) - 400×300px cards

## Accessibility
- All inputs maintain consistent dark backgrounds with visible borders (no white inputs in dark mode)
- Focus states: 3px cyan outline with 4px offset
- Minimum contrast ratio: 7:1 for text, 4.5:1 for interactive elements
- Keyboard navigation: Tab order follows visual hierarchy, Escape closes modals/overlays
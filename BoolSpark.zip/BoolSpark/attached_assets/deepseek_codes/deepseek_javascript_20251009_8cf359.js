import * as pdfjsLib from 'pdfjs-dist/build/pdf';
import { read, utils } from 'docx';

// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js`;

export class FileParser {
  static async parsePDF(file) {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      
      let text = '';
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        text += content.items.map(item => item.str).join(' ') + '\n';
      }
      
      return text.trim();
    } catch (error) {
      throw new Error(`Failed to parse PDF: ${error.message}`);
    }
  }

  static async parseDOCX(file) {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const doc = await read(arrayBuffer);
      return utils.extractRawText(doc).trim();
    } catch (error) {
      throw new Error(`Failed to parse DOCX: ${error.message}`);
    }
  }

  static async extractText(file) {
    const fileType = file.name.split('.').pop().toLowerCase();
    
    switch (fileType) {
      case 'pdf':
        return await this.parsePDF(file);
      case 'docx':
        return await this.parseDOCX(file);
      default:
        throw new Error('Unsupported file format. Please upload PDF or DOCX.');
    }
  }

  static validateFile(file) {
    const validTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    const maxSize = 5 * 1024 * 1024; // 5MB

    if (!validTypes.includes(file.type) && !file.name.match(/\.(pdf|docx)$/i)) {
      throw new Error('Please upload a PDF or DOCX file');
    }

    if (file.size > maxSize) {
      throw new Error('File size must be less than 5MB');
    }

    if (file.size === 0) {
      throw new Error('File appears to be empty');
    }

    return true;
  }
}
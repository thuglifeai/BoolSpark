import React, { useState } from 'react';
import { Copy, Download, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';

const BooleanResults = ({ results, extractedText }) => {
  const [copiedLevel, setCopiedLevel] = useState(null);

  const copyToClipboard = async (text, level) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedLevel(level);
      setTimeout(() => setCopiedLevel(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const downloadBoolean = (text, level) => {
    const element = document.createElement('a');
    const file = new Blob([text], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `boolean-search-${level.toLowerCase()}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const getLevelConfig = (level) => {
    const configs = {
      basic: {
        color: 'green',
        bgColor: 'bg-green-50 dark:bg-green-900/20',
        borderColor: 'border-green-200 dark:border-green-800',
        textColor: 'text-green-800 dark:text-green-300',
        icon: '🟢'
      },
      intermediate: {
        color: 'blue',
        bgColor: 'bg-blue-50 dark:bg-blue-900/20',
        borderColor: 'border-blue-200 dark:border-blue-800',
        textColor: 'text-blue-800 dark:text-blue-300',
        icon: '🔵'
      },
      advanced: {
        color: 'purple',
        bgColor: 'bg-purple-50 dark:bg-purple-900/20',
        borderColor: 'border-purple-200 dark:border-purple-800',
        textColor: 'text-purple-800 dark:text-purple-300',
        icon: '🟣'
      }
    };
    return configs[level] || configs.basic;
  };

  if (!results) return null;

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8 animate-slide-up">
      {/* Summary Card */}
      <div className="glass-effect rounded-2xl p-6 shadow-lg">
        <div className="flex items-start space-x-3">
          <Sparkles className="text-primary-500 mt-1 flex-shrink-0" size={24} />
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              {results.jobTitle}
            </h3>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
              {results.summary}
            </p>
          </div>
        </div>
      </div>

      {/* Boolean Results */}
      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-3">
        {['basic', 'intermediate', 'advanced'].map((level) => {
          const config = getLevelConfig(level);
          const levelText = results[level];
          
          if (!levelText) return null;

          return (
            <div
              key={level}
              className={`${config.bgColor} ${config.borderColor} border-2 rounded-xl p-6 transition-all duration-300 hover:shadow-lg`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <span className="text-lg">{config.icon}</span>
                  <h4 className={`font-semibold ${config.textColor} capitalize`}>
                    {level} Search
                  </h4>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => copyToClipboard(levelText, level)}
                    className={`p-2 rounded-lg transition-colors ${
                      copiedLevel === level
                        ? 'bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400'
                        : 'bg-white/50 dark:bg-gray-800/50 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                    }`}
                    title="Copy to clipboard"
                  >
                    {copiedLevel === level ? <CheckCircle2 size={18} /> : <Copy size={18} />}
                  </button>
                  <button
                    onClick={() => downloadBoolean(levelText, level)}
                    className="p-2 rounded-lg bg-white/50 dark:bg-gray-800/50 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
                    title="Download"
                  >
                    <Download size={18} />
                  </button>
                </div>
              </div>

              <div className="bg-white/50 dark:bg-gray-800/50 rounded-lg p-4">
                <pre className="text-sm text-gray-800 dark:text-gray-200 whitespace-pre-wrap break-words font-mono">
                  {levelText}
                </pre>
              </div>

              {copiedLevel === level && (
                <div className="mt-3 flex items-center space-x-2 text-green-600 dark:text-green-400 text-sm">
                  <CheckCircle2 size={16} />
                  <span>Copied to clipboard!</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Extracted Text Preview */}
      {extractedText && (
        <div className="glass-effect rounded-2xl p-6">
          <div className="flex items-center space-x-2 mb-4">
            <FileText size={20} className="text-primary-500" />
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Extracted Text Preview
            </h3>
          </div>
          <div className="bg-white/50 dark:bg-gray-800/50 rounded-lg p-4 max-h-60 overflow-y-auto">
            <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
              {extractedText.substring(0, 500)}
              {extractedText.length > 500 && '...'}
            </p>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            {extractedText.length} characters extracted • Showing first 500 characters
          </p>
        </div>
      )}
    </div>
  );
};

export default BooleanResults;
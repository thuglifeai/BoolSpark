export const BOOLEAN_QUOTES = [
  {
    text: "⚡ Boolean logic: Where precision meets possibility in talent discovery!",
    author: "BoolSpark AI"
  },
  {
    text: "🔍 Every great hire starts with the right search string!",
    author: "Recruitment Wisdom"
  },
  {
    text: "💡 AI + Boolean = Recruitment Superpowers!",
    author: "Tech Sourcing"
  },
  {
    text: "🚀 Ignite your search with smart Boolean combinations!",
    author: "BoolSpark"
  },
  {
    text: "🎯 Precision sourcing begins with perfect Boolean strings!",
    author: "Talent Excellence"
  },
  {
    text: "🌟 Transform job descriptions into candidate magnets!",
    author: "AI Recruitment"
  },
  {
    text: "⚡ Simplify complexity, amplify results with Boolean magic!",
    author: "Sourcing Pro"
  }
];

export const DEEPSEEK_API_URL = 'https://api.deepseek.com/v1/chat/completions';
export const DEEPSEEK_API_KEY = 'sk-1dcfd643b6cf46c3a5fbdda2984c1e6a';

export const BOOLEAN_PROMPT = `You are a senior recruitment sourcer expert in Boolean search strings. Analyze the job description and generate THREE levels of Boolean search strings:

BASIC LEVEL: Core skills and job title combinations
INTERMEDIATE LEVEL: Added technologies and platforms
ADVANCED LEVEL: Comprehensive with locations and site filters

Return ONLY valid JSON in this exact format:
{
  "jobTitle": "extracted job title",
  "summary": "brief 2-3 line summary",
  "basic": "basic boolean string",
  "intermediate": "intermediate boolean string", 
  "advanced": "advanced boolean string"
}

Ensure all strings are properly formatted with correct Boolean syntax and parentheses.`;
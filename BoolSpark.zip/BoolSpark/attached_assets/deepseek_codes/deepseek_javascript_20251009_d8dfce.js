import { DEEPSEEK_API_URL, DEEPSEEK_API_KEY, BOOLEAN_PROMPT } from './constants.js';

export class DeepSeekAPI {
  static async generateBooleanSearch(jdText) {
    try {
      const response = await fetch(DEEPSEEK_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${DEEPSEEK_API_KEY}`
        },
        body: JSON.stringify({
          model: 'deepseek-chat',
          messages: [
            {
              role: 'system',
              content: BOOLEAN_PROMPT
            },
            {
              role: 'user',
              content: `Job Description: ${jdText.substring(0, 4000)}` // Limit text length
            }
          ],
          temperature: 0.7,
          max_tokens: 2000
        })
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }

      const data = await response.json();
      
      if (!data.choices || !data.choices[0]) {
        throw new Error('Invalid API response format');
      }

      const content = data.choices[0].message.content;
      
      try {
        return JSON.parse(content);
      } catch (parseError) {
        // Fallback if JSON parsing fails
        return this.createFallbackResponse(jdText);
      }
    } catch (error) {
      console.error('DeepSeek API Error:', error);
      throw new Error(`Failed to generate Boolean search: ${error.message}`);
    }
  }

  static createFallbackResponse(jdText) {
    const words = jdText.split(/\s+/).filter(word => word.length > 3);
    const skills = words.slice(0, 5).join(' OR ');
    
    return {
      jobTitle: "Software Professional",
      summary: "AI-generated Boolean search based on job description analysis",
      basic: `("Software Engineer" OR "Developer") AND (${skills})`,
      intermediate: `("Software Engineer" OR "Senior Developer") AND (${skills}) AND (AWS OR Cloud)`,
      advanced: `("Software Engineer" OR "Senior Developer") AND (${skills}) AND (AWS OR Cloud) AND site:linkedin.com/in ("Malaysia" OR "Singapore")`
    };
  }
}
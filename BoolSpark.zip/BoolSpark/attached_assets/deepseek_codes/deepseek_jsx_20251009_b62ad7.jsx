import React, { useState, useEffect } from 'react';
import { Quote } from 'lucide-react';
import { BOOLEAN_QUOTES } from '../utils/constants.js';

const QuoteSection = () => {
  const [currentQuote, setCurrentQuote] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuote((prev) => (prev + 1) % BOOLEAN_QUOTES.length);
    }, 5000); // Change quote every 5 seconds

    return () => clearInterval(interval);
  }, []);

  const quote = BOOLEAN_QUOTES[currentQuote];

  return (
    <div className="text-center space-y-4 animate-pulse-slow">
      <div className="flex justify-center">
        <Quote className="text-primary-500" size={24} />
      </div>
      <blockquote className="max-w-2xl mx-auto">
        <p className="text-xl font-medium text-gray-800 dark:text-white leading-relaxed">
          {quote.text}
        </p>
        <footer className="mt-3">
          <cite className="text-sm text-primary-600 dark:text-primary-400 not-italic">
            — {quote.author}
          </cite>
        </footer>
      </blockquote>
    </div>
  );
};

export default QuoteSection;
import { useState } from 'react';
import { FileParser } from '../utils/fileParser.js';
import { DeepSeekAPI } from '../utils/api.js';

export const useBooleanGenerator = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [results, setResults] = useState(null);
  const [extractedText, setExtractedText] = useState('');

  const generateBooleanSearch = async (file) => {
    setLoading(true);
    setError(null);
    setResults(null);
    setExtractedText('');

    try {
      // Validate and parse file
      FileParser.validateFile(file);
      const text = await FileParser.extractText(file);
      setExtractedText(text);

      // Generate Boolean search using AI
      const booleanResults = await DeepSeekAPI.generateBooleanSearch(text);
      setResults(booleanResults);
      
    } catch (err) {
      setError(err.message);
      console.error('Generation error:', err);
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setLoading(false);
    setError(null);
    setResults(null);
    setExtractedText('');
  };

  return {
    loading,
    error,
    results,
    extractedText,
    generateBooleanSearch,
    reset
  };
};
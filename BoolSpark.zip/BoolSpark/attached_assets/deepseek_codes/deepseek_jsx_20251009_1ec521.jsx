import React from 'react';
import { Sun, Moon, Monitor } from 'lucide-react';

const ThemeToggle = ({ theme, onThemeChange }) => {
  const themes = [
    { id: 'light', name: 'Light', icon: Sun },
    { id: 'dark', name: 'Dark', icon: Moon },
    { id: 'system', name: 'System', icon: Monitor },
  ];

  return (
    <div className="flex items-center space-x-1 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-xl p-1 shadow-lg border border-gray-200 dark:border-gray-700">
      {themes.map(({ id, name, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onThemeChange(id)}
          className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
            theme === id
              ? 'bg-primary-500 text-white shadow-md'
              : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-700'
          }`}
          title={name}
        >
          <Icon size={16} />
          <span className="hidden sm:inline">{name}</span>
        </button>
      ))}
    </div>
  );
};

export default ThemeToggle;
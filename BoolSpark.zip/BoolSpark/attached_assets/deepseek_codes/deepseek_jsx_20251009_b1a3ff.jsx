import React from 'react';
import { useState } from 'react';
import { Github, Heart, Zap } from 'lucide-react';

// Components
import FileUpload from './components/FileUpload.jsx';
import BooleanResults from './components/BooleanResults.jsx';
import ThemeToggle from './components/ThemeToggle.jsx';
import QuoteSection from './components/QuoteSection.jsx';

// Hooks
import { useTheme } from './hooks/useTheme.js';
import { useBooleanGenerator } from './hooks/useBooleanGenerator.js';

function App() {
  const { theme, toggleTheme } = useTheme();
  const { loading, error, results, extractedText, generateBooleanSearch, reset } = useBooleanGenerator();
  const [hasUploaded, setHasUploaded] = useState(false);

  const handleFileUpload = async (file) => {
    setHasUploaded(true);
    await generateBooleanSearch(file);
  };

  const handleReset = () => {
    reset();
    setHasUploaded(false);
  };

  return (
    <div className="min-h-screen gradient-bg transition-colors duration-300">
      {/* Header */}
      <header className="relative pt-8 pb-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0 mb-8">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-white/20 rounded-xl backdrop-blur-sm">
                <Zap className="text-white" size={32} />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">BoolSpark ⚡</h1>
                <p className="text-white/80 text-sm">Ignite Your Search. Simplify the Hunt.</p>
              </div>
            </div>
            
            <ThemeToggle theme={theme} onThemeChange={toggleTheme} />
          </div>

          <QuoteSection />
        </div>
      </header>

      {/* Main Content */}
      <main className="relative -mt-8 pb-20">
        <div className="container mx-auto px-4">
          <div className="glass-effect rounded-3xl shadow-2xl p-8 max-w-6xl mx-auto">
            {!hasUploaded ? (
              <div className="text-center space-y-8">
                <div className="space-y-4">
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                    Upload Job Description
                  </h2>
                  <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                    Upload a PDF or DOCX job description and let AI generate optimized Boolean search strings for your candidate sourcing.
                  </p>
                </div>

                <FileUpload onFileUpload={handleFileUpload} loading={loading} />
              </div>
            ) : (
              <div className="space-y-8">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                    Boolean Search Results
                  </h2>
                  <button
                    onClick={handleReset}
                    className="px-4 py-2 bg-primary-500 hover:bg-primary-600 text-white rounded-lg transition-colors font-medium"
                  >
                    Upload New File
                  </button>
                </div>

                {loading && (
                  <div className="text-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-500 mx-auto mb-4"></div>
                    <p className="text-gray-600 dark:text-gray-300">
                      Analyzing job description and generating Boolean searches...
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                      This may take a few moments
                    </p>
                  </div>
                )}

                {error && (
                  <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-6 text-center">
                    <div className="flex items-center justify-center space-x-2 text-red-600 dark:text-red-400 mb-2">
                      <AlertCircle size={24} />
                      <h3 className="text-lg font-semibold">Generation Error</h3>
                    </div>
                    <p className="text-red-700 dark:text-red-300">{error}</p>
                    <button
                      onClick={handleReset}
                      className="mt-4 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors"
                    >
                      Try Again
                    </button>
                  </div>
                )}

                {results && (
                  <BooleanResults results={results} extractedText={extractedText} />
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/20 bg-white/10 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="flex items-center space-x-2 text-white/80">
              <span>Developed with</span>
              <Heart size={16} className="text-red-400" />
              <span>by Thug Life Dev</span>
            </div>
            
            <div className="flex items-center space-x-4 text-white/80">
              <span>Powered by DeepSeek API</span>
              <div className="w-px h-4 bg-white/30"></div>
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-white transition-colors flex items-center space-x-1"
              >
                <Github size={16} />
                <span>GitHub</span>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
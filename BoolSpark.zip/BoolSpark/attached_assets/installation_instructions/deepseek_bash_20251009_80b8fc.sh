mkdir boolspark
cd boolspark
npm install
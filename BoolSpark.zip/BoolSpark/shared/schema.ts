import { z } from "zod";
import { pgTable, serial, text, timestamp, varchar, jsonb, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

export const generateBooleanSchema = z.object({
  text: z.string().min(1, "Job description text is required"),
  apiKey: z.string().optional(),
});

export const booleanResponseSchema = z.object({
  basic: z.string(),
  advanced: z.string(),
  linkedin: z.string(),
  insights: z.string(),
});

export type GenerateBooleanRequest = z.infer<typeof generateBooleanSchema>;
export type BooleanResponse = z.infer<typeof booleanResponseSchema>;

// Database Tables
export const booleanStrings = pgTable("boolean_strings", {
  id: serial("id").primaryKey(),
  jobTitle: text("job_title"),
  jobDescription: text("job_description").notNull(),
  basic: text("basic").notNull(),
  advanced: text("advanced").notNull(),
  linkedin: text("linkedin").notNull(),
  insights: text("insights").notNull(),
  fileName: text("file_name"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const sharedLinks = pgTable("shared_links", {
  id: serial("id").primaryKey(),
  booleanStringId: integer("boolean_string_id").references(() => booleanStrings.id).notNull(),
  shareSlug: varchar("share_slug", { length: 255 }).unique().notNull(),
  viewCount: integer("view_count").default(0).notNull(),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const analyticsEvents = pgTable("analytics_events", {
  id: serial("id").primaryKey(),
  eventType: varchar("event_type", { length: 50 }).notNull(),
  booleanStringId: integer("boolean_string_id").references(() => booleanStrings.id),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert Schemas
export const insertBooleanStringSchema = createInsertSchema(booleanStrings).omit({
  id: true,
  createdAt: true,
});

export const insertSharedLinkSchema = createInsertSchema(sharedLinks).omit({
  id: true,
  createdAt: true,
});

export const insertAnalyticsEventSchema = createInsertSchema(analyticsEvents).omit({
  id: true,
  createdAt: true,
});

// Types
export type BooleanString = typeof booleanStrings.$inferSelect;
export type InsertBooleanString = z.infer<typeof insertBooleanStringSchema>;

export type SharedLink = typeof sharedLinks.$inferSelect;
export type InsertSharedLink = z.infer<typeof insertSharedLinkSchema>;

export type AnalyticsEvent = typeof analyticsEvents.$inferSelect;
export type InsertAnalyticsEvent = z.infer<typeof insertAnalyticsEventSchema>;

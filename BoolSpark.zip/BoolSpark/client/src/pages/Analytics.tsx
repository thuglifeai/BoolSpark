import { useQuery } from '@tanstack/react-query'
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { TrendingUp, FileText, Code, Activity, ArrowLeft } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Link } from 'wouter'
import { format } from 'date-fns'

interface DailyUsage {
  date: string
  count: number
}

interface FileType {
  fileType: string
  count: number
}

interface PopularSkill {
  skill: string
  count: number
}

interface AnalyticsOverview {
  totalGenerations: number
  recentEvents: Array<{ id: number; eventType: string; createdAt: string }>
}

const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff7c7c', '#a78bfa', '#f59e0b']

export default function Analytics() {
  const { data: dailyUsage, isLoading: loadingDaily } = useQuery<DailyUsage[]>({
    queryKey: ['/api/analytics/daily-usage'],
  })

  const { data: fileTypes, isLoading: loadingFiles } = useQuery<FileType[]>({
    queryKey: ['/api/analytics/file-types'],
  })

  const { data: popularSkills, isLoading: loadingSkills } = useQuery<PopularSkill[]>({
    queryKey: ['/api/analytics/popular-skills'],
  })

  const { data: overview, isLoading: loadingOverview } = useQuery<AnalyticsOverview>({
    queryKey: ['/api/analytics/overview'],
  })

  const isLoading = loadingDaily || loadingFiles || loadingSkills || loadingOverview

  const formattedDailyUsage = dailyUsage?.map(item => ({
    ...item,
    date: format(new Date(item.date), 'MMM dd')
  })) || []

  const topSkills = popularSkills?.slice(0, 10) || []
  const fileTypeData = fileTypes || []

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border sticky top-0 z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold">Analytics Dashboard</h1>
            </div>
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Generator
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Overview Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Generations
              </CardTitle>
              <Activity className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold" data-testid="total-generations">
                {isLoading ? '...' : overview?.totalGenerations || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                All-time Boolean strings generated
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                File Uploads
              </CardTitle>
              <FileText className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {isLoading ? '...' : fileTypes?.reduce((acc, curr) => curr.fileType !== 'Text Input' ? acc + curr.count : acc, 0) || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                PDF & DOCX files processed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Top Skill
              </CardTitle>
              <Code className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {isLoading ? '...' : topSkills[0]?.skill || 'N/A'}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Most searched skill: {topSkills[0]?.count || 0} times
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Success Rate
              </CardTitle>
              <TrendingUp className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {isLoading ? '...' : overview?.totalGenerations ? '100%' : '0%'}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Generation success rate
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Daily Usage Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Daily Usage (Last 30 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={formattedDailyUsage}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="date" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--background))', border: '1px solid hsl(var(--border))' }}
                    labelStyle={{ color: 'hsl(var(--foreground))' }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="count" 
                    stroke="#8884d8" 
                    strokeWidth={2}
                    name="Generations"
                    dot={{ fill: '#8884d8', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* File Type Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>File Type Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={fileTypeData}
                    dataKey="count"
                    nameKey="fileType"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    label={(entry) => `${entry.fileType}: ${entry.count}`}
                  >
                    {fileTypeData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--background))', border: '1px solid hsl(var(--border))' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Popular Skills Chart */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Top 10 Most Popular Skills</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={topSkills}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="skill" className="text-xs" angle={-45} textAnchor="end" height={100} />
                  <YAxis className="text-xs" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--background))', border: '1px solid hsl(var(--border))' }}
                    labelStyle={{ color: 'hsl(var(--foreground))' }}
                  />
                  <Legend />
                  <Bar dataKey="count" fill="#8884d8" name="Mentions" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}

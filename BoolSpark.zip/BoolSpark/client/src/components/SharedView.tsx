import { useParams } from 'wouter'
import { useQuery } from '@tanstack/react-query'
import { Zap, Copy, AlertCircle, Loader2, Eye, Home } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useToast } from '@/hooks/use-toast'
import { useTheme } from './ThemeProvider'
import { Sun, Moon, Monitor } from 'lucide-react'
import { Link } from 'wouter'

interface SharedData {
  id: number
  jobTitle: string | null
  basic: string
  advanced: string
  linkedin: string
  insights: string
  viewCount: number
  expiresAt: string | null
}

export default function SharedView() {
  const { shareSlug } = useParams<{ shareSlug: string }>()
  const { toast } = useToast()
  const { theme, toggleTheme } = useTheme()

  const { data, isLoading, error } = useQuery<SharedData>({
    queryKey: ['/api/share', shareSlug],
    queryFn: async () => {
      const response = await fetch(`/api/share/${shareSlug}`)
      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || 'Failed to load shared content')
      }
      return response.json()
    }
  })

  const handleCopy = () => {
    if (!data) return
    const fullText = `BASIC BOOLEAN:\n${data.basic}\n\nADVANCED BOOLEAN:\n${data.advanced}\n\nLINKEDIN X-RAY:\n${data.linkedin}`
    navigator.clipboard.writeText(fullText)
    toast({
      title: 'Copied!',
      description: 'Boolean strings copied to clipboard',
    })
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border sticky top-0 z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="gradient-bg w-10 h-10 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold gradient-text">BoolSpark</h1>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Link href="/">
                <Button variant="outline" size="sm">
                  <Home className="w-4 h-4 mr-2" />
                  Create Your Own
                </Button>
              </Link>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                aria-label="Toggle theme"
              >
                {theme === 'light' && <Sun className="w-5 h-5" />}
                {theme === 'dark' && <Moon className="w-5 h-5" />}
                {theme === 'system' && <Monitor className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {isLoading && (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
            <p className="text-muted-foreground">Loading shared content...</p>
          </div>
        )}

        {error && (
          <div className="flex flex-col items-center justify-center py-20">
            <AlertCircle className="w-12 h-12 text-destructive mb-4" />
            <p className="text-lg font-semibold mb-2">Failed to load shared content</p>
            <p className="text-muted-foreground">{error instanceof Error ? error.message : 'Unknown error'}</p>
          </div>
        )}

        {data && (
          <div className="max-w-4xl mx-auto space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-2xl font-bold">{data.jobTitle || 'Untitled Position'}</h2>
                    <p className="text-sm text-muted-foreground flex items-center gap-2 mt-1">
                      <Eye className="w-4 h-4" />
                      Viewed {data.viewCount} time{data.viewCount !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <Button onClick={handleCopy} data-testid="copy-shared">
                    <Copy className="w-4 h-4 mr-2" />
                    Copy All
                  </Button>
                </div>

                <div className="space-y-4">
                  <div className="bg-background rounded-lg p-4 border border-border">
                    <p className="text-xs font-medium text-muted-foreground mb-2">BASIC BOOLEAN</p>
                    <code className="block font-mono text-sm text-foreground break-words">
                      {data.basic}
                    </code>
                  </div>
                  <div className="bg-background rounded-lg p-4 border border-border">
                    <p className="text-xs font-medium text-muted-foreground mb-2">ADVANCED BOOLEAN</p>
                    <code className="block font-mono text-sm text-foreground break-words">
                      {data.advanced}
                    </code>
                  </div>
                  <div className="bg-background rounded-lg p-4 border border-border">
                    <p className="text-xs font-medium text-muted-foreground mb-2">LINKEDIN X-RAY</p>
                    <code className="block font-mono text-sm text-foreground break-words">
                      {data.linkedin}
                    </code>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-accent/50 rounded-lg border border-accent">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Zap className="w-5 h-5 text-accent-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-1">AI Insights</p>
                      <p className="text-xs text-muted-foreground">{data.insights}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  )
}

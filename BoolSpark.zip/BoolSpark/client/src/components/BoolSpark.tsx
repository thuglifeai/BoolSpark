import { useState, useRef, useCallback, useEffect } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { Upload, Zap, Sun, Moon, Monitor, Copy, Download, AlertCircle, CheckCircle, Info, X, History as HistoryIcon, Trash2, Clock, Settings as SettingsIcon, Loader2, FileText, Share2, BarChart3, RefreshCw } from 'lucide-react'
import { Link } from 'wouter'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useTheme } from './ThemeProvider'
import { parseFile, validateFile, formatFileSize, type ParsedContent } from '@/lib/fileParser'
import { apiRequest, queryClient } from '@/lib/queryClient'
import { useToast } from '@/hooks/use-toast'
import { formatDistanceToNow } from 'date-fns'

interface BooleanStrings {
  basic: string
  advanced: string
  linkedin: string
  insights: string
  id?: number
}

interface GenerateRequest {
  text: string
  apiKey?: string
  fileName?: string
}

interface HistoryItem {
  id: number
  jobTitle: string | null
  jobDescription: string
  basic: string
  advanced: string
  linkedin: string
  insights: string
  fileName: string | null
  createdAt: string
}

interface FormatPreferences {
  andOperator: 'AND' | '&' | '+'
  orOperator: 'OR' | '|' | ','
  quoteStyle: 'double' | 'single' | 'none'
  parenthesesStyle: 'round' | 'square' | 'curly' | 'none'
  caseStyle: 'upper' | 'lower' | 'preserve'
}

interface BatchItem {
  id: string
  file: File
  status: 'pending' | 'processing' | 'completed' | 'error'
  parsedContent?: ParsedContent
  booleanStrings?: BooleanStrings
  error?: string
}

export default function BoolSpark() {
  const { theme, toggleTheme } = useTheme()
  const { toast } = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [parsedContent, setParsedContent] = useState<ParsedContent | null>(null)
  const [apiKey, setApiKey] = useState('')
  const [booleanStrings, setBooleanStrings] = useState<BooleanStrings | null>(null)
  const [isDragOver, setIsDragOver] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [batchMode, setBatchMode] = useState(false)
  const [batchItems, setBatchItems] = useState<BatchItem[]>([])
  const [activeBatchTab, setActiveBatchTab] = useState(0)
  const [showShareDialog, setShowShareDialog] = useState(false)
  const [shareUrl, setShareUrl] = useState('')
  const [currentBooleanStringId, setCurrentBooleanStringId] = useState<number | null>(null)
  const [preferences, setPreferences] = useState<FormatPreferences>(() => {
    const saved = localStorage.getItem('boolspark-preferences')
    return saved ? JSON.parse(saved) : {
      andOperator: 'AND',
      orOperator: 'OR',
      quoteStyle: 'double',
      parenthesesStyle: 'round',
      caseStyle: 'preserve'
    }
  })

  // Save preferences to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('boolspark-preferences', JSON.stringify(preferences))
  }, [preferences])

  const generateMutation = useMutation({
    mutationFn: async (request: GenerateRequest) => {
      const response = await apiRequest('POST', '/api/generate-boolean', request)
      return response.json()
    },
    onSuccess: (data: BooleanStrings & { id?: number }) => {
      setBooleanStrings(data)
      if (data.id) {
        setCurrentBooleanStringId(data.id)
      }
      toast({
        title: 'Success!',
        description: 'Boolean string generated successfully!',
      })
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to generate boolean string',
        variant: 'destructive',
      })
    },
  })

  const handleFileSelect = useCallback(async (file: File) => {
    const validation = validateFile(file)
    if (!validation.isValid) {
      toast({
        title: 'Invalid file',
        description: validation.error,
        variant: 'destructive',
      })
      return
    }

    try {
      const content = await parseFile(file)
      setUploadedFile(file)
      setParsedContent(content)
      setBooleanStrings(null)
      toast({
        title: 'File uploaded',
        description: 'File uploaded and parsed successfully',
      })
    } catch (error) {
      toast({
        title: 'Parse error',
        description: error instanceof Error ? error.message : 'Failed to parse file',
        variant: 'destructive',
      })
    }
  }, [toast])

  const processBatchItems = useCallback(async (items: BatchItem[]) => {
    for (let i = 0; i < items.length; i++) {
      const item = items[i]
      
      setBatchItems(prev => prev.map(b => 
        b.id === item.id ? { ...b, status: 'processing' } : b
      ))

      const validation = validateFile(item.file)
      if (!validation.isValid) {
        setBatchItems(prev => prev.map(b => 
          b.id === item.id ? { ...b, status: 'error', error: validation.error } : b
        ))
        continue
      }

      try {
        const content = await parseFile(item.file)
        
        setBatchItems(prev => prev.map(b => 
          b.id === item.id ? { ...b, parsedContent: content } : b
        ))

        const response = await apiRequest('POST', '/api/generate-boolean', {
          text: content.text,
          apiKey: apiKey.trim() || undefined,
          fileName: item.file.name
        })
        const data = await response.json()

        setBatchItems(prev => prev.map(b => 
          b.id === item.id ? { ...b, status: 'completed', booleanStrings: data } : b
        ))
      } catch (error) {
        setBatchItems(prev => prev.map(b => 
          b.id === item.id ? { 
            ...b, 
            status: 'error', 
            error: error instanceof Error ? error.message : 'Processing failed' 
          } : b
        ))
      }
    }

    toast({
      title: 'Batch processing complete',
      description: `Processed ${items.length} files`,
    })
  }, [apiKey, toast])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(false)
    
    const file = e.dataTransfer.files[0]
    if (file) {
      handleFileSelect(file)
    }
  }, [handleFileSelect])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragOver(true)
  }, [])

  const handleDragLeave = useCallback(() => {
    setIsDragOver(false)
  }, [])

  const handleFileInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return

    if (batchMode && files.length > 1) {
      const items: BatchItem[] = Array.from(files).map(file => ({
        id: Math.random().toString(36).substr(2, 9),
        file,
        status: 'pending' as const
      }))
      setBatchItems(items)
      setActiveBatchTab(0)
      processBatchItems(items)
    } else {
      const file = files[0]
      handleFileSelect(file)
    }
  }, [batchMode, handleFileSelect, processBatchItems])

  const handleGenerate = useCallback(() => {
    if (!parsedContent) {
      toast({
        title: 'No file uploaded',
        description: 'Please upload a job description first',
        variant: 'destructive',
      })
      return
    }

    generateMutation.mutate({
      text: parsedContent.text,
      apiKey: apiKey.trim() || undefined,
      fileName: uploadedFile?.name
    })
  }, [parsedContent, apiKey, uploadedFile, generateMutation, toast])

  // History queries and mutations
  const { data: historyItems = [], refetch: refetchHistory } = useQuery<HistoryItem[]>({
    queryKey: ['/api/history'],
    enabled: showHistory,
  })

  const shareMutation = useMutation({
    mutationFn: async (booleanStringId: number) => {
      const response = await apiRequest('POST', '/api/share', { booleanStringId })
      return response.json()
    },
    onSuccess: (data: { shareSlug: string }) => {
      const baseUrl = window.location.origin
      const url = `${baseUrl}/share/${data.shareSlug}`
      setShareUrl(url)
      setShowShareDialog(true)
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to create share link',
        variant: 'destructive',
      })
    }
  })

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/history/${id}`, null)
      return response.json()
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/history'] })
      toast({
        title: 'Deleted',
        description: 'History item deleted successfully',
      })
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to delete history item',
        variant: 'destructive',
      })
    },
  })

  const handleLoadHistoryItem = useCallback((item: HistoryItem) => {
    setBooleanStrings({
      basic: item.basic,
      advanced: item.advanced,
      linkedin: item.linkedin,
      insights: item.insights,
      id: item.id
    })
    setCurrentBooleanStringId(item.id)
    setParsedContent({
      text: item.jobDescription,
      title: item.jobTitle || undefined,
      pages: undefined
    })
    setShowHistory(false)
    toast({
      title: 'Loaded',
      description: 'History item loaded successfully',
    })
  }, [toast])

  const formatBooleanString = useCallback((str: string): string => {
    let formatted = str

    // Apply operator replacements
    formatted = formatted.replace(/\bAND\b/g, preferences.andOperator)
    formatted = formatted.replace(/\bOR\b/g, preferences.orOperator)

    // Apply quote style
    if (preferences.quoteStyle === 'single') {
      formatted = formatted.replace(/"/g, "'")
    } else if (preferences.quoteStyle === 'none') {
      formatted = formatted.replace(/["']/g, '')
    }

    // Apply parentheses style
    if (preferences.parenthesesStyle === 'square') {
      formatted = formatted.replace(/\(/g, '[').replace(/\)/g, ']')
    } else if (preferences.parenthesesStyle === 'curly') {
      formatted = formatted.replace(/\(/g, '{').replace(/\)/g, '}')
    } else if (preferences.parenthesesStyle === 'none') {
      formatted = formatted.replace(/[()]/g, '')
    }

    // Apply case style
    if (preferences.caseStyle === 'upper') {
      formatted = formatted.toUpperCase()
    } else if (preferences.caseStyle === 'lower') {
      formatted = formatted.toLowerCase()
    }

    return formatted
  }, [preferences])

  const handleCopy = useCallback(() => {
    if (!booleanStrings) return

    const fullText = `BASIC BOOLEAN:\n${formatBooleanString(booleanStrings.basic)}\n\nADVANCED BOOLEAN:\n${formatBooleanString(booleanStrings.advanced)}\n\nLINKEDIN X-RAY:\n${formatBooleanString(booleanStrings.linkedin)}`
    
    navigator.clipboard.writeText(fullText).then(() => {
      toast({
        title: 'Copied!',
        description: 'Boolean strings copied to clipboard',
      })
    }).catch(() => {
      toast({
        title: 'Copy failed',
        description: 'Failed to copy to clipboard',
        variant: 'destructive',
      })
    })
  }, [booleanStrings, formatBooleanString, toast])

  const handleDownload = useCallback(() => {
    if (!booleanStrings) return

    const content = `BOOLSPARK - GENERATED BOOLEAN STRINGS\n${'='.repeat(50)}\n\nBASIC BOOLEAN:\n${formatBooleanString(booleanStrings.basic)}\n\nADVANCED BOOLEAN:\n${formatBooleanString(booleanStrings.advanced)}\n\nLINKEDIN X-RAY:\n${formatBooleanString(booleanStrings.linkedin)}\n\nAI INSIGHTS:\n${booleanStrings.insights}\n\n${'='.repeat(50)}\nGenerated by BoolSpark - AI Boolean Search Generator`
    
    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'boolean-strings.txt'
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    
    toast({
      title: 'Downloaded!',
      description: 'Boolean strings downloaded successfully',
    })
  }, [booleanStrings, formatBooleanString, toast])

  const handleRefresh = useCallback(() => {
    if (!parsedContent) return

    generateMutation.mutate({
      text: parsedContent.text,
      apiKey: apiKey.trim() || undefined,
      fileName: uploadedFile?.name,
      regenerate: true
    })
    
    toast({
      title: 'Regenerating...',
      description: 'Creating a fresh variation for you',
    })
  }, [parsedContent, apiKey, uploadedFile, generateMutation, toast])

  const handleRemoveFile = useCallback(() => {
    setUploadedFile(null)
    setParsedContent(null)
    setBooleanStrings(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
    toast({
      title: 'File removed',
      description: 'File has been removed',
    })
  }, [toast])

  const quotes = [
    { text: "🔍 Smart recruiters don't search harder — they search smarter.", author: "Recruiter Wisdom" },
    { text: "🤖 Let the Boolean be your compass in the talent jungle.", author: "Sourcing Strategy" },
    { text: "⚡ One Boolean string can spark a hundred great hires.", author: "Recruitment Excellence" },
    { text: "🧠 Boolean isn't magic — it's logic with a recruiter's heart.", author: "Talent Intelligence" },
    { text: "💡 A good Boolean string speaks louder than 100 job posts.", author: "Smart Sourcing" },
    { text: "🎯 Precision in your search defines the brilliance of your hire.", author: "Hiring Mastery" },
    { text: "🔥 Boolean mastery: when your keywords hit like a sniper shot.", author: "Elite Recruiting" },
    { text: "🕵️‍♂️ Boolean: the Sherlock Holmes of sourcing.", author: "Detective Recruiting" },
    { text: "💪 Behind every successful recruiter is a powerful Boolean.", author: "Recruitment Hero" },
    { text: "🌈 Boolean is the art of turning words into results.", author: "Creative Sourcing" },
    { text: "⚡ Your next hire is just one Boolean string away.", author: "Opportunity Knocks" },
    { text: "🧩 Boolean logic — because randomness doesn't hire talent.", author: "Strategic Hiring" },
    { text: "🚀 From keyword chaos to candidate clarity — Boolean does that.", author: "Clarity First" },
    { text: "🔑 The right keywords unlock the right humans.", author: "Talent Unlocked" },
    { text: "🧙‍♂️ Boolean is not a spell, but it sure feels like one.", author: "Recruiting Magic" },
    { text: "💻 Your Boolean string is your digital fingerprint as a sourcer.", author: "Digital Recruiting" },
    { text: "🧭 Boolean logic — your North Star in data overload.", author: "Navigation Expert" },
    { text: "🌟 Great recruiters don't chase; they Boolean attract.", author: "Magnetic Sourcing" },
    { text: "🏹 Hit your target talent pool with Boolean precision.", author: "Bullseye Hiring" },
    { text: "🧃 Sip coffee. Build Boolean. Repeat.", author: "Daily Ritual" },
    { text: "📚 Every great hire starts with a great Boolean.", author: "Foundation First" },
    { text: "🛠️ Boolean is the recruiter's Swiss Army knife.", author: "Tool Master" },
    { text: "🧬 Boolean — the DNA of every talent search.", author: "Search Science" },
    { text: "🕰️ Spend minutes building a Boolean, save hours sourcing.", author: "Time Saver" },
    { text: "💼 Boolean isn't just skill — it's recruiter street smarts.", author: "Street Smart" },
    { text: "🔄 Keep calm and Boolean on.", author: "Stay Cool" },
    { text: "📡 Boolean: connecting humans through search logic.", author: "Human Connection" },
    { text: "❤️ Boolean with love, hire with purpose.", author: "Purpose Driven" }
  ]

  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuoteIndex((prev) => (prev + 1) % quotes.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen transition-colors duration-300">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-lg bg-background/80 border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 sm:w-14 sm:h-14 gradient-bg rounded-xl flex items-center justify-center shadow-2xl transform hover:scale-110 transition-transform">
                <Zap className="w-7 h-7 sm:w-8 sm:h-8 text-white animate-pulse" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-primary tracking-tight">BoolSpark</h1>
                <p className="text-xs sm:text-sm text-muted-foreground hidden sm:block font-medium">AI Boolean Search Generator</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Link href="/analytics">
                <Button
                  variant="ghost"
                  size="icon"
                  data-testid="analytics-link"
                  aria-label="View analytics"
                  title="Analytics dashboard"
                >
                  <BarChart3 className="w-5 h-5" />
                </Button>
              </Link>
              <Button
                variant={batchMode ? "default" : "ghost"}
                size="icon"
                onClick={() => {
                  setBatchMode(!batchMode)
                  setBatchItems([])
                  setUploadedFile(null)
                  setParsedContent(null)
                  setBooleanStrings(null)
                }}
                data-testid="batch-toggle"
                aria-label="Toggle batch mode"
                title={batchMode ? "Batch mode active" : "Enable batch mode"}
              >
                <FileText className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowSettings(!showSettings)}
                data-testid="settings-toggle"
                aria-label="Toggle settings"
                title="Format settings"
              >
                <SettingsIcon className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowHistory(!showHistory)}
                data-testid="history-toggle"
                aria-label="Toggle history"
                title="View history"
              >
                <HistoryIcon className="w-5 h-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                data-testid="theme-toggle"
                aria-label="Toggle theme"
                title={`Current: ${theme === 'system' ? 'System' : theme === 'light' ? 'Light' : 'Dark'}`}
              >
                {theme === 'light' && <Sun className="w-5 h-5" />}
                {theme === 'dark' && <Moon className="w-5 h-5" />}
                {theme === 'system' && <Monitor className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Quote Section */}
        <div className="text-center mb-12 animate-slide-up" data-testid="quote-section">
          <blockquote className="max-w-2xl mx-auto">
            <p className="text-lg sm:text-xl font-medium text-foreground mb-2">
              {quotes[currentQuoteIndex].text}
            </p>
            <cite className="text-sm text-muted-foreground not-italic">
              - {quotes[currentQuoteIndex].author}
            </cite>
          </blockquote>
        </div>
        {/* Hero Section */}
        <section className="text-center mb-12 relative">
          <div className="absolute inset-0 -z-10 overflow-hidden">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-gradient-to-r from-primary/20 via-purple-500/20 to-primary/20 rounded-full blur-3xl animate-pulse"></div>
          </div>
          <h2 className="text-4xl sm:text-6xl font-extrabold mb-6 gradient-text leading-tight">
            Generate Boolean Strings<br />
            <span className="text-3xl sm:text-5xl">Instantly with AI</span>
          </h2>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            Upload job descriptions and let AI craft powerful Boolean search strings for your recruitment needs. 
            <span className="block mt-2 font-semibold text-foreground">Save time and find the perfect candidates faster.</span>
          </p>
        </section>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* File Upload Section */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Upload className="w-5 h-5 text-primary" />
                  Upload Job Description{batchMode ? 's' : ''}
                </h3>

                {/* Drop Zone */}
                <div
                  className={`border-2 border-dashed rounded-lg p-8 sm:p-12 text-center transition-all cursor-pointer ${
                    isDragOver ? 'drag-over' : 'border-border hover:border-primary hover:bg-accent/50'
                  }`}
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onClick={() => fileInputRef.current?.click()}
                  data-testid="file-drop-zone"
                >
                  <div className="flex flex-col items-center gap-4">
                    <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center">
                      <Upload className="w-8 h-8 text-accent-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-medium mb-1">Drop your file{batchMode ? 's' : ''} here or <span className="text-primary">browse</span></p>
                      <p className="text-xs text-muted-foreground">Supports PDF and DOCX (Max 10MB{batchMode ? ' each' : ''})</p>
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".pdf,.docx"
                      multiple={batchMode}
                      className="hidden"
                      onChange={handleFileInputChange}
                      data-testid="file-input"
                    />
                  </div>
                </div>

                {/* Uploaded File Display */}
                {uploadedFile && (
                  <div className="mt-4 p-4 bg-muted rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                          <Upload className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-medium" data-testid="file-name">{uploadedFile.name}</p>
                          <p className="text-xs text-muted-foreground" data-testid="file-size">{formatFileSize(uploadedFile.size)}</p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={handleRemoveFile}
                        data-testid="remove-file"
                      >
                        <X className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* API Key Input */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Zap className="w-5 h-5 text-secondary" />
                  DeepSeek API Configuration
                </h3>
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="api-key">API Key <span className="text-xs text-muted-foreground">(Optional)</span></Label>
                    <Input
                      id="api-key"
                      type="password"
                      placeholder="sk-xxxxxxxxxxxxxxxxxxxxxxxx"
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      data-testid="input-api-key"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground flex items-start gap-2">
                    <Info className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    Leave empty to use default API key. Your key is stored locally and never shared.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Generate Button */}
            <Button
              onClick={handleGenerate}
              disabled={!parsedContent || generateMutation.isPending}
              className="w-full gradient-bg text-white font-semibold py-4 px-6 shadow-lg hover:shadow-xl transform hover:scale-[1.02] active:scale-[0.98] transition-all"
              data-testid="button-generate"
            >
              <Zap className="w-5 h-5 mr-2" />
              {generateMutation.isPending ? 'Generating...' : 'Generate Boolean String'}
            </Button>
          </div>

          {/* Output Section */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold flex items-center gap-2">
                    <Upload className="w-5 h-5 text-primary" />
                    Generated Boolean String
                  </h3>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleRefresh}
                      disabled={!parsedContent || generateMutation.isPending}
                      title="Regenerate boolean strings"
                      data-testid="button-refresh"
                      className="text-primary hover:text-primary"
                    >
                      <RefreshCw className={`w-5 h-5 ${generateMutation.isPending ? 'animate-spin' : ''}`} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => currentBooleanStringId && shareMutation.mutate(currentBooleanStringId)}
                      disabled={!currentBooleanStringId || shareMutation.isPending}
                      title="Share link"
                      data-testid="button-share"
                    >
                      {shareMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Share2 className="w-5 h-5" />}
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleCopy}
                      disabled={!booleanStrings}
                      title="Copy to clipboard"
                      data-testid="button-copy"
                    >
                      <Copy className="w-5 h-5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleDownload}
                      disabled={!booleanStrings}
                      title="Download as TXT"
                      data-testid="button-download"
                    >
                      <Download className="w-5 h-5" />
                    </Button>
                  </div>
                </div>

                <div className="min-h-[400px] bg-muted/50 rounded-lg p-6 border border-border">
                  {!booleanStrings && !generateMutation.isPending && batchItems.length === 0 && (
                    <div className="h-full flex flex-col items-center justify-center text-center py-12" data-testid="empty-state">
                      <div className="w-20 h-20 bg-accent rounded-full flex items-center justify-center mb-4">
                        <Zap className="w-10 h-10 text-accent-foreground" />
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">No boolean string generated yet</p>
                      <p className="text-xs text-muted-foreground">Upload {batchMode ? 'job descriptions' : 'a job description'} to get started</p>
                    </div>
                  )}

                  {/* Batch Results */}
                  {batchItems.length > 0 && (
                    <div data-testid="batch-results">
                      <div className="flex gap-2 mb-4 flex-wrap">
                        {batchItems.map((item, index) => (
                          <Button
                            key={item.id}
                            variant={activeBatchTab === index ? "default" : "outline"}
                            size="sm"
                            onClick={() => setActiveBatchTab(index)}
                            data-testid={`batch-tab-${index}`}
                            className="flex items-center gap-2"
                          >
                            {item.status === 'processing' && <Loader2 className="w-3 h-3 animate-spin" />}
                            {item.status === 'completed' && <CheckCircle className="w-3 h-3" />}
                            {item.status === 'error' && <AlertCircle className="w-3 h-3" />}
                            <span className="truncate max-w-[120px]">{item.file.name}</span>
                          </Button>
                        ))}
                      </div>

                      {batchItems[activeBatchTab] && (
                        <div>
                          {batchItems[activeBatchTab].status === 'processing' && (
                            <div className="flex flex-col items-center justify-center py-12">
                              <Loader2 className="w-10 h-10 text-primary animate-spin mb-4" />
                              <p className="text-sm text-muted-foreground">Processing {batchItems[activeBatchTab].file.name}...</p>
                            </div>
                          )}

                          {batchItems[activeBatchTab].status === 'error' && (
                            <div className="flex flex-col items-center justify-center py-12">
                              <AlertCircle className="w-10 h-10 text-destructive mb-4" />
                              <p className="text-sm text-muted-foreground">{batchItems[activeBatchTab].error}</p>
                            </div>
                          )}

                          {batchItems[activeBatchTab].status === 'completed' && batchItems[activeBatchTab].booleanStrings && (
                            <div>
                              <div className="space-y-4">
                                <div className="bg-background rounded-lg p-4 border border-border">
                                  <p className="text-xs font-medium text-muted-foreground mb-2">BASIC BOOLEAN</p>
                                  <code className="block font-mono text-sm text-foreground break-words">
                                    {batchItems[activeBatchTab].booleanStrings!.basic}
                                  </code>
                                </div>
                                <div className="bg-background rounded-lg p-4 border border-border">
                                  <p className="text-xs font-medium text-muted-foreground mb-2">ADVANCED BOOLEAN</p>
                                  <code className="block font-mono text-sm text-foreground break-words">
                                    {batchItems[activeBatchTab].booleanStrings!.advanced}
                                  </code>
                                </div>
                                <div className="bg-background rounded-lg p-4 border border-border">
                                  <p className="text-xs font-medium text-muted-foreground mb-2">LINKEDIN X-RAY</p>
                                  <code className="block font-mono text-sm text-foreground break-words">
                                    {batchItems[activeBatchTab].booleanStrings!.linkedin}
                                  </code>
                                </div>
                              </div>

                              <div className="mt-6 p-4 bg-accent/50 rounded-lg border border-accent">
                                <div className="flex items-start gap-3">
                                  <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                                    <Zap className="w-5 h-5 text-accent-foreground" />
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium mb-1">AI Insights</p>
                                    <p className="text-xs text-muted-foreground">
                                      {batchItems[activeBatchTab].booleanStrings!.insights}
                                    </p>
                                  </div>
                                </div>
                              </div>

                              <div className="flex gap-3 mt-6">
                                <Button
                                  onClick={() => {
                                    const item = batchItems[activeBatchTab]
                                    if (item.booleanStrings) {
                                      const fullText = `BASIC BOOLEAN:\n${formatBooleanString(item.booleanStrings.basic)}\n\nADVANCED BOOLEAN:\n${formatBooleanString(item.booleanStrings.advanced)}\n\nLINKEDIN X-RAY:\n${formatBooleanString(item.booleanStrings.linkedin)}`
                                      navigator.clipboard.writeText(fullText)
                                      toast({
                                        title: 'Copied!',
                                        description: 'Boolean strings copied to clipboard',
                                      })
                                    }
                                  }}
                                  className="flex-1"
                                  data-testid="copy-batch-item"
                                >
                                  <Copy className="w-4 h-4 mr-2" />
                                  Copy
                                </Button>
                                <Button
                                  variant="outline"
                                  onClick={() => {
                                    const item = batchItems[activeBatchTab]
                                    if (item.booleanStrings) {
                                      const content = `BOOLSPARK - GENERATED BOOLEAN STRINGS\n${'='.repeat(50)}\n\nBASIC BOOLEAN:\n${formatBooleanString(item.booleanStrings.basic)}\n\nADVANCED BOOLEAN:\n${formatBooleanString(item.booleanStrings.advanced)}\n\nLINKEDIN X-RAY:\n${formatBooleanString(item.booleanStrings.linkedin)}\n\nAI INSIGHTS:\n${item.booleanStrings.insights}\n\n${'='.repeat(50)}\nGenerated by BoolSpark - AI Boolean Search Generator`
                                      const blob = new Blob([content], { type: 'text/plain' })
                                      const url = URL.createObjectURL(blob)
                                      const a = document.createElement('a')
                                      a.href = url
                                      a.download = `boolean-strings-${item.file.name}.txt`
                                      document.body.appendChild(a)
                                      a.click()
                                      document.body.removeChild(a)
                                      URL.revokeObjectURL(url)
                                      toast({
                                        title: 'Downloaded!',
                                        description: 'Boolean strings downloaded successfully',
                                      })
                                    }
                                  }}
                                  className="flex-1"
                                  data-testid="download-batch-item"
                                >
                                  <Download className="w-4 h-4 mr-2" />
                                  Download
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {generateMutation.isPending && (
                    <div className="h-full flex flex-col items-center justify-center py-12" data-testid="loading-state">
                      <div className="relative w-20 h-20 mb-4">
                        <div className="absolute inset-0 gradient-bg rounded-full animate-ping opacity-75"></div>
                        <div className="relative w-20 h-20 gradient-bg rounded-full flex items-center justify-center">
                          <Zap className="w-10 h-10 text-white animate-pulse" />
                        </div>
                      </div>
                      <p className="text-sm font-medium mb-1">Generating Boolean String...</p>
                      <p className="text-xs text-muted-foreground">AI is analyzing your job description</p>
                    </div>
                  )}

                  {booleanStrings && (
                    <div data-testid="generated-output">
                      <div className="space-y-4">
                        <div className="bg-background rounded-lg p-4 border border-border">
                          <p className="text-xs font-medium text-muted-foreground mb-2">BASIC BOOLEAN</p>
                          <code className="block font-mono text-sm text-foreground break-words" data-testid="boolean-basic">
                            {booleanStrings.basic}
                          </code>
                        </div>
                        <div className="bg-background rounded-lg p-4 border border-border">
                          <p className="text-xs font-medium text-muted-foreground mb-2">ADVANCED BOOLEAN</p>
                          <code className="block font-mono text-sm text-foreground break-words" data-testid="boolean-advanced">
                            {booleanStrings.advanced}
                          </code>
                        </div>
                        <div className="bg-background rounded-lg p-4 border border-border">
                          <p className="text-xs font-medium text-muted-foreground mb-2">LINKEDIN X-RAY</p>
                          <code className="block font-mono text-sm text-foreground break-words" data-testid="boolean-linkedin">
                            {booleanStrings.linkedin}
                          </code>
                        </div>
                      </div>

                      <div className="mt-6 p-4 bg-accent/50 rounded-lg border border-accent">
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                            <Zap className="w-5 h-5 text-accent-foreground" />
                          </div>
                          <div>
                            <p className="text-sm font-medium mb-1">AI Insights</p>
                            <p className="text-xs text-muted-foreground" data-testid="ai-insights">
                              {booleanStrings.insights}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Info className="w-5 h-5 text-secondary" />
                  Quick Tips
                </h3>
                <ul className="space-y-3 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-secondary mt-0.5 flex-shrink-0" />
                    Upload clear, detailed job descriptions for better Boolean strings
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-secondary mt-0.5 flex-shrink-0" />
                    Use Advanced Boolean for complex requirements
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-secondary mt-0.5 flex-shrink-0" />
                    LinkedIn X-Ray strings work best on Google Search
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-secondary mt-0.5 flex-shrink-0" />
                    Test and refine strings based on search results
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Features Grid */}
        <section className="mt-16">
          <h3 className="text-2xl font-bold text-center mb-8">Why Choose BoolSpark?</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 gradient-bg rounded-lg flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold mb-2">AI-Powered</h4>
                <p className="text-sm text-muted-foreground">DeepSeek AI analyzes job descriptions to create precise Boolean strings</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 gradient-bg rounded-lg flex items-center justify-center mb-4">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold mb-2">Save Time</h4>
                <p className="text-sm text-muted-foreground">Generate complex Boolean searches in seconds, not minutes</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 gradient-bg rounded-lg flex items-center justify-center mb-4">
                  <AlertCircle className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold mb-2">Secure</h4>
                <p className="text-sm text-muted-foreground">Your data is processed securely and never stored</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="w-12 h-12 gradient-bg rounded-lg flex items-center justify-center mb-4">
                  <Download className="w-6 h-6 text-white" />
                </div>
                <h4 className="font-semibold mb-2">Easy Export</h4>
                <p className="text-sm text-muted-foreground">Copy or download Boolean strings for immediate use</p>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-border py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-muted-foreground">
          <p>Developed with ❤️ by Thug Life Dev | Powered by DeepSeek API</p>
        </div>
      </footer>

      {/* History Sidebar */}
      {showHistory && (
        <div className="fixed inset-0 z-50 flex" data-testid="history-sidebar">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setShowHistory(false)}></div>
          <div className="relative ml-auto w-full sm:w-96 bg-background h-full shadow-2xl overflow-hidden flex flex-col">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <HistoryIcon className="w-5 h-5 text-primary" />
                History
              </h3>
              <Button variant="ghost" size="icon" onClick={() => setShowHistory(false)} data-testid="close-history">
                <X className="w-5 h-5" />
              </Button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {historyItems.length === 0 ? (
                <div className="text-center py-12">
                  <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No history yet</p>
                  <p className="text-sm text-muted-foreground mt-2">Generated Boolean strings will appear here</p>
                </div>
              ) : (
                historyItems.map((item) => (
                  <Card key={item.id} className="hover:shadow-md transition-shadow cursor-pointer" data-testid={`history-item-${item.id}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex-1" onClick={() => handleLoadHistoryItem(item)}>
                          <h4 className="font-medium text-sm line-clamp-2 mb-1" data-testid={`history-title-${item.id}`}>
                            {item.jobTitle || 'Untitled'}
                          </h4>
                          {item.fileName && (
                            <p className="text-xs text-muted-foreground flex items-center gap-1">
                              <Upload className="w-3 h-3" />
                              {item.fileName}
                            </p>
                          )}
                          <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}
                          </p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={(e) => {
                            e.stopPropagation()
                            deleteMutation.mutate(item.id)
                          }}
                          data-testid={`delete-history-${item.id}`}
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2">{item.jobDescription}</p>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" data-testid="settings-modal">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setShowSettings(false)}></div>
          <Card className="relative w-full max-w-md mx-4 z-10">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <SettingsIcon className="w-5 h-5 text-primary" />
                  Format Settings
                </h3>
                <Button variant="ghost" size="icon" onClick={() => setShowSettings(false)} data-testid="close-settings">
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="and-operator">AND Operator</Label>
                  <select
                    id="and-operator"
                    value={preferences.andOperator}
                    onChange={(e) => setPreferences({...preferences, andOperator: e.target.value as 'AND' | '&' | '+'})}
                    className="w-full p-2 border border-border rounded-md bg-background"
                    data-testid="select-and-operator"
                  >
                    <option value="AND">AND</option>
                    <option value="&">&</option>
                    <option value="+">+</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="or-operator">OR Operator</Label>
                  <select
                    id="or-operator"
                    value={preferences.orOperator}
                    onChange={(e) => setPreferences({...preferences, orOperator: e.target.value as 'OR' | '|' | ','})}
                    className="w-full p-2 border border-border rounded-md bg-background"
                    data-testid="select-or-operator"
                  >
                    <option value="OR">OR</option>
                    <option value="|">|</option>
                    <option value=",">,</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quote-style">Quote Style</Label>
                  <select
                    id="quote-style"
                    value={preferences.quoteStyle}
                    onChange={(e) => setPreferences({...preferences, quoteStyle: e.target.value as 'double' | 'single' | 'none'})}
                    className="w-full p-2 border border-border rounded-md bg-background"
                    data-testid="select-quote-style"
                  >
                    <option value="double">Double Quotes (")</option>
                    <option value="single">Single Quotes (')</option>
                    <option value="none">No Quotes</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="parentheses-style">Parentheses Style</Label>
                  <select
                    id="parentheses-style"
                    value={preferences.parenthesesStyle}
                    onChange={(e) => setPreferences({...preferences, parenthesesStyle: e.target.value as 'round' | 'square' | 'curly' | 'none'})}
                    className="w-full p-2 border border-border rounded-md bg-background"
                    data-testid="select-parentheses-style"
                  >
                    <option value="round">Round Parentheses ()</option>
                    <option value="square">Square Brackets []</option>
                    <option value="curly">Curly Braces {}</option>
                    <option value="none">No Parentheses</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="case-style">Case Style</Label>
                  <select
                    id="case-style"
                    value={preferences.caseStyle}
                    onChange={(e) => setPreferences({...preferences, caseStyle: e.target.value as 'upper' | 'lower' | 'preserve'})}
                    className="w-full p-2 border border-border rounded-md bg-background"
                    data-testid="select-case-style"
                  >
                    <option value="preserve">Preserve Original</option>
                    <option value="upper">UPPERCASE</option>
                    <option value="lower">lowercase</option>
                  </select>
                </div>

                <div className="pt-4 border-t border-border">
                  <p className="text-sm text-muted-foreground mb-2">Preview:</p>
                  <code className="text-sm bg-muted p-2 rounded block">{formatBooleanString('(Python AND Django) OR Flask')}</code>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Share Dialog */}
      {showShareDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" data-testid="share-dialog">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setShowShareDialog(false)}></div>
          <Card className="relative w-full max-w-md mx-4 z-10">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  <Share2 className="w-5 h-5 text-primary" />
                  Share Link Created
                </h3>
                <Button variant="ghost" size="icon" onClick={() => setShowShareDialog(false)} data-testid="close-share-dialog">
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Share this link with others to let them view your generated Boolean strings:
                </p>
                
                <div className="flex gap-2">
                  <Input
                    value={shareUrl}
                    readOnly
                    className="font-mono text-sm"
                    data-testid="share-url-input"
                  />
                  <Button
                    onClick={() => {
                      navigator.clipboard.writeText(shareUrl)
                      toast({
                        title: 'Copied!',
                        description: 'Share link copied to clipboard',
                      })
                    }}
                    data-testid="copy-share-url"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                </div>

                <p className="text-xs text-muted-foreground">
                  This link will remain active indefinitely. Anyone with the link can view the Boolean strings.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

export interface ParsedContent {
  text: string
  metadata?: {
    title?: string
    pages?: number
  }
}

export async function parseFile(file: File): Promise<ParsedContent> {
  if (file.type === 'application/pdf') {
    return parsePDF(file)
  } else if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    return parseDOCX(file)
  } else {
    throw new Error('Unsupported file type')
  }
}

async function parsePDF(file: File): Promise<ParsedContent> {
  try {
    const arrayBuffer = await file.arrayBuffer()
    
    const formData = new FormData()
    formData.append('file', new Blob([arrayBuffer], { type: 'application/pdf' }))
    
    const response = await fetch('/api/parse-pdf', {
      method: 'POST',
      body: formData
    })
    
    if (!response.ok) {
      throw new Error(`Failed to parse PDF: ${response.statusText}`)
    }
    
    const data = await response.json()
    
    return {
      text: data.text,
      metadata: {
        pages: data.pages,
        title: data.title
      }
    }
  } catch (error) {
    throw new Error(`Failed to parse PDF: ${error instanceof Error ? error.message : 'Unknown error'}`)
  }
}

async function parseDOCX(file: File): Promise<ParsedContent> {
  try {
    const arrayBuffer = await file.arrayBuffer()
    
    const formData = new FormData()
    formData.append('file', new Blob([arrayBuffer], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }))
    
    const response = await fetch('/api/parse-docx', {
      method: 'POST',
      body: formData
    })
    
    if (!response.ok) {
      throw new Error(`Failed to parse DOCX: ${response.statusText}`)
    }
    
    const data = await response.json()
    
    return {
      text: data.text,
      metadata: {
        title: data.title || file.name.replace(/\.[^/.]+$/, "")
      }
    }
  } catch (error) {
    throw new Error(`Failed to parse DOCX: ${error instanceof Error ? error.message : 'Unknown error'}`)
  }
}

export function validateFile(file: File): { isValid: boolean; error?: string } {
  const validTypes = [
    'application/pdf', 
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ]
  
  if (!validTypes.includes(file.type)) {
    return { isValid: false, error: 'Please upload a PDF or DOCX file' }
  }
  
  const maxSize = 10 * 1024 * 1024 // 10MB
  if (file.size > maxSize) {
    return { isValid: false, error: 'File size must be less than 10MB' }
  }
  
  return { isValid: true }
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes'
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i]
}

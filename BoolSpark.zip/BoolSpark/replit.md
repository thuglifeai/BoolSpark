# BoolSpark - AI Boolean Search Generator

## Overview

BoolSpark is an AI-powered recruitment tool that transforms job descriptions into optimized Boolean search strings. The application accepts job descriptions via file upload (PDF/DOCX), then generates multiple levels of Boolean search strings (basic, advanced, LinkedIn-optimized) to help recruiters find the right candidates. Built with a modern React frontend and Express backend, it leverages AI to automate the complex process of creating effective candidate search queries.

## Recent Updates (October 2025)

**Boolean Generation Fix** - Resolved truncation issue where boolean strings were appearing as incomplete fragments:
- Root cause: DeepSeek API `max_tokens` was only 1000, causing truncated responses
- Secondary issue: Regex parser couldn't handle escaped quotes in JSON responses
- **Solution**: 
  - Increased `max_tokens` from 1000 → 3000 for complete responses
  - Enhanced regex pattern to properly parse escaped quotes: `((?:[^"\\\\]|\\\\.)*)`
  - Improved AI prompt with clearer examples and formatting instructions
- **Result**: All boolean strings now generate complete, properly formatted queries

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom theme configuration supporting light/dark modes
- **State Management**: TanStack Query (React Query) for server state and data fetching
- **Form Handling**: React Hook Form with Zod schema validation
- **File Parsing**: Client-side parsing capabilities for PDF and DOCX files with server-side fallback

**Design Decisions**:
- Single-page application architecture for seamless user experience
- Component-based architecture with reusable UI elements from Shadcn/ui
- Theme system with localStorage persistence for user preference
- File processing handled through dedicated API endpoints to offload heavy parsing from client

### Backend Architecture
- **Framework**: Express.js with TypeScript running on Node.js
- **API Design**: RESTful endpoints with JSON payloads
- **File Processing**: Multer for multipart/form-data handling with 10MB file size limit
- **Document Parsing**: 
  - PDF parsing via pdf-parse library
  - DOCX parsing via mammoth library
- **Development**: Hot module replacement via Vite middleware in development mode
- **Production**: Compiled with esbuild for optimal performance

**Design Decisions**:
- Stateless API design - no session management or authentication required
- Middleware-based request logging for API monitoring
- Raw body preservation for webhook-style integrations
- Separation of file parsing logic to dedicated endpoints for modularity

### Data Storage
- **Database**: PostgreSQL via Neon serverless driver
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Location**: `shared/schema.ts` for cross-environment type sharing
- **Migrations**: Drizzle Kit for schema management with migrations stored in `./migrations`

**Design Decisions**:
- Schema definitions shared between client and server via `shared/` directory
- Zod schemas for runtime validation matching database types
- Database URL configured via environment variable
- Currently minimal storage requirements (schema suggests boolean generation feature)

### External Dependencies

**AI Services**:
- DeepSeek API integration for AI-powered Boolean string generation
- API key management through optional request parameters or environment variables
- Structured prompts for consistent output formatting

**File Processing Libraries**:
- `pdf-parse`: PDF text extraction
- `mammoth`: DOCX document parsing
- `multer`: Multipart form data handling
- `adm-zip`: Archive manipulation capabilities

**UI Component Libraries**:
- `@radix-ui/*`: Headless UI primitives (20+ components)
- `tailwindcss`: Utility-first CSS framework
- `class-variance-authority`: Component variant management
- `lucide-react`: Icon library

**Development Tools**:
- `@replit/vite-plugin-*`: Replit-specific development plugins
- `vite`: Frontend build tool and dev server
- `tsx`: TypeScript execution for Node.js
- `esbuild`: Production bundler for backend code

**Database & ORM**:
- `@neondatabase/serverless`: PostgreSQL driver optimized for serverless
- `drizzle-orm`: TypeScript ORM
- `drizzle-kit`: Schema migration tooling
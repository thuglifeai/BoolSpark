import type { Express } from "express";
import { createServer, type Server } from "http";
import { generateBooleanSchema, type BooleanResponse } from "@shared/schema";
import { z } from "zod";
import multer from "multer";
import mammoth from "mammoth";
import { createRequire } from 'module';
import { storage } from "./storage";

const require = createRequire(import.meta.url);

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // PDF parsing endpoint
  app.post("/api/parse-pdf", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // Use CommonJS require for pdf-parse (it's a CommonJS module)
      const pdfParse = require('pdf-parse');
      const data = await pdfParse(req.file.buffer);
      
      res.json({
        text: data.text,
        pages: data.numpages,
        title: data.info?.Title || null
      });
    } catch (error) {
      console.error('Error parsing PDF:', error);
      res.status(500).json({ 
        message: `Failed to parse PDF: ${error instanceof Error ? error.message : 'Unknown error'}` 
      });
    }
  });

  // DOCX parsing endpoint
  app.post("/api/parse-docx", upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const result = await mammoth.extractRawText({ buffer: req.file.buffer });
      
      res.json({
        text: result.value,
        title: req.file.originalname.replace(/\.[^/.]+$/, "")
      });
    } catch (error) {
      console.error('Error parsing DOCX:', error);
      res.status(500).json({ 
        message: `Failed to parse DOCX: ${error instanceof Error ? error.message : 'Unknown error'}` 
      });
    }
  });

  app.post("/api/generate-boolean", async (req, res) => {
    try {
      const { text, apiKey, regenerate } = z.object({
        text: z.string(),
        apiKey: z.string().optional(),
        fileName: z.string().optional(),
        regenerate: z.boolean().optional()
      }).parse(req.body);
      
      // Use provided API key or fall back to environment variable
      const deepseekApiKey = apiKey || process.env.DEEPSEEK_API_KEY || process.env.API_KEY;
      
      if (!deepseekApiKey) {
        return res.status(400).json({ 
          message: "DeepSeek API key is required. Please provide one in the request or set DEEPSEEK_API_KEY environment variable." 
        });
      }

      // Call DeepSeek API
      const prompt = `Analyze this job description and generate Boolean search strings for recruitment:

Job Description:
${text}

Create THREE complete Boolean search strings:

1. BASIC: Core skills and job title with OR operators
   Example: AEM OR "Adobe Experience Manager" OR Java OR HTL OR React

2. ADVANCED: Comprehensive string with AND/OR logic, synonyms, and variations
   Example: (AEM OR "Adobe Experience Manager") AND (Java OR J2EE) AND (React OR "Front-end")

3. LINKEDIN X-RAY: Optimized for LinkedIn with site:linkedin.com/in/ prefix
   Example: site:linkedin.com/in/ (AEM OR "Adobe Experience Manager") AND Java

4. INSIGHTS: Brief explanation of your search strategy

IMPORTANT: Return ONLY valid JSON. When keywords contain spaces, use quotes. Single words don't need quotes.

{
  "basic": "your complete basic boolean string",
  "advanced": "your complete advanced boolean string", 
  "linkedin": "your complete linkedin string",
  "insights": "your strategy explanation"
}`;

      const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${deepseekApiKey}`
        },
        body: JSON.stringify({
          model: 'deepseek-chat',
          messages: [
            {
              role: 'system',
              content: 'You are an expert recruitment consultant specializing in Boolean search string generation. You MUST respond with complete, valid JSON containing four fields: basic, advanced, linkedin, and insights. Each boolean string must be fully complete with proper syntax.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          max_tokens: 3000,
          temperature: regenerate ? 0.7 : 0.3
        })
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('DeepSeek API error:', errorData);
        return res.status(response.status).json({ 
          message: `DeepSeek API error: ${response.status} ${response.statusText}` 
        });
      }

      const data = await response.json();
      
      if (!data.choices?.[0]?.message?.content) {
        return res.status(500).json({ 
          message: "Invalid response from DeepSeek API" 
        });
      }

      const aiResponse = data.choices[0].message.content;

      let parsedContent;
      try {
        parsedContent = JSON.parse(aiResponse);
      } catch (parseError) {
        // If JSON parsing fails, extract content manually
        const content = data.choices[0].message.content;
        parsedContent = {
          basic: extractSection(content, 'basic') || generateFallbackBasic(text),
          advanced: extractSection(content, 'advanced') || generateFallbackAdvanced(text),
          linkedin: extractSection(content, 'linkedin') || generateFallbackLinkedin(text),
          insights: extractSection(content, 'insights') || "AI-generated Boolean strings based on job description analysis."
        };
      }

      const result: BooleanResponse = {
        basic: parsedContent.basic || generateFallbackBasic(text),
        advanced: parsedContent.advanced || generateFallbackAdvanced(text),
        linkedin: parsedContent.linkedin || generateFallbackLinkedin(text),
        insights: parsedContent.insights || "AI-generated Boolean strings based on job description analysis."
      };

      // Save to history
      const jobTitle = extractJobTitle(text);
      const fileName = req.body.fileName || null;
      const savedString = await storage.saveBooleanString({
        jobTitle,
        jobDescription: text,
        fileName,
        ...result
      });

      // Track generation event
      await storage.trackEvent({
        eventType: 'generation',
        booleanStringId: savedString.id,
        metadata: { jobTitle, hasFileName: !!fileName }
      });

      res.json({ ...result, id: savedString.id });
    } catch (error) {
      console.error('Error generating boolean strings:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request data", 
          errors: error.errors 
        });
      }

      res.status(500).json({ 
        message: "Internal server error while generating Boolean strings" 
      });
    }
  });

  // History routes
  app.get("/api/history", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const history = await storage.getBooleanStrings(limit);
      res.json(history);
    } catch (error) {
      console.error('Error fetching history:', error);
      res.status(500).json({ message: "Failed to fetch history" });
    }
  });

  app.get("/api/history/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const item = await storage.getBooleanStringById(id);
      
      if (!item) {
        return res.status(404).json({ message: "History item not found" });
      }
      
      res.json(item);
    } catch (error) {
      console.error('Error fetching history item:', error);
      res.status(500).json({ message: "Failed to fetch history item" });
    }
  });

  app.delete("/api/history/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteBooleanString(id);
      res.json({ message: "History item deleted successfully" });
    } catch (error) {
      console.error('Error deleting history item:', error);
      res.status(500).json({ message: "Failed to delete history item" });
    }
  });

  // Shareable links routes
  app.post("/api/share", async (req, res) => {
    try {
      const { booleanStringId, expiresInDays } = req.body;
      
      if (!booleanStringId) {
        return res.status(400).json({ message: "Boolean string ID is required" });
      }

      // Check if boolean string exists
      const booleanString = await storage.getBooleanStringById(booleanStringId);
      if (!booleanString) {
        return res.status(404).json({ message: "Boolean string not found" });
      }

      // Generate unique share slug (8 characters alphanumeric)
      const shareSlug = Math.random().toString(36).substring(2, 10);

      // Calculate expiration date if provided
      let expiresAt: Date | null = null;
      if (expiresInDays && expiresInDays > 0) {
        expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + expiresInDays);
      }

      const sharedLink = await storage.createSharedLink({
        booleanStringId,
        shareSlug,
        expiresAt
      });

      res.json(sharedLink);
    } catch (error) {
      console.error('Error creating shared link:', error);
      res.status(500).json({ message: "Failed to create shared link" });
    }
  });

  app.get("/api/share/:shareSlug", async (req, res) => {
    try {
      const { shareSlug } = req.params;
      const sharedLink = await storage.getSharedLink(shareSlug);

      if (!sharedLink) {
        return res.status(404).json({ message: "Shared link not found" });
      }

      // Check if link has expired
      if (sharedLink.expiresAt && new Date(sharedLink.expiresAt) < new Date()) {
        return res.status(410).json({ message: "This shared link has expired" });
      }

      // Increment view count
      await storage.incrementSharedLinkViews(shareSlug);

      // Get the boolean string data
      const booleanString = await storage.getBooleanStringById(sharedLink.booleanStringId);
      
      if (!booleanString) {
        return res.status(404).json({ message: "Boolean string data not found" });
      }

      res.json({
        ...booleanString,
        viewCount: sharedLink.viewCount + 1,
        expiresAt: sharedLink.expiresAt
      });
    } catch (error) {
      console.error('Error fetching shared link:', error);
      res.status(500).json({ message: "Failed to fetch shared link" });
    }
  });

  // Analytics routes
  app.get("/api/analytics/daily-usage", async (req, res) => {
    try {
      const daysParam = req.query.days ? parseInt(req.query.days as string) : 30;
      const days = isNaN(daysParam) || daysParam < 1 ? 30 : Math.min(daysParam, 365);
      const data = await storage.getDailyUsage(days);
      res.json(data);
    } catch (error) {
      console.error('Error fetching daily usage:', error);
      res.status(500).json({ message: "Failed to fetch daily usage" });
    }
  });

  app.get("/api/analytics/file-types", async (req, res) => {
    try {
      const data = await storage.getFileTypeBreakdown();
      res.json(data);
    } catch (error) {
      console.error('Error fetching file type breakdown:', error);
      res.status(500).json({ message: "Failed to fetch file type breakdown" });
    }
  });

  app.get("/api/analytics/popular-skills", async (req, res) => {
    try {
      const data = await storage.getPopularSkills();
      res.json(data);
    } catch (error) {
      console.error('Error fetching popular skills:', error);
      res.status(500).json({ message: "Failed to fetch popular skills" });
    }
  });

  app.get("/api/analytics/overview", async (req, res) => {
    try {
      const analytics = await storage.getAnalytics();
      res.json(analytics);
    } catch (error) {
      console.error('Error fetching analytics overview:', error);
      res.status(500).json({ message: "Failed to fetch analytics overview" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper functions for content extraction and fallbacks
function extractSection(content: string, section: string): string | null {
  // Try to find the section with better handling of escaped quotes
  const regex = new RegExp(`"${section}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`,'i');
  const match = content.match(regex);
  if (match) {
    // Unescape the string
    return match[1].replace(/\\"/g, '"').replace(/\\\\/g, '\\');
  }
  return null;
}

function generateFallbackBasic(text: string): string {
  const words = extractKeywords(text);
  return words.slice(0, 5).map(word => `"${word}"`).join(' OR ');
}

function generateFallbackAdvanced(text: string): string {
  const words = extractKeywords(text);
  return `(${words.slice(0, 3).map(word => `"${word}"`).join(' OR ')}) AND (${words.slice(3, 6).map(word => `"${word}"`).join(' OR ')})`;
}

function generateFallbackLinkedin(text: string): string {
  const words = extractKeywords(text);
  return `site:linkedin.com/in/ (${words.slice(0, 3).map(word => `"${word}"`).join(' OR ')})`;
}

function extractKeywords(text: string): string[] {
  // Simple keyword extraction - in production, use more sophisticated NLP
  const commonWords = ['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must', 'shall', 'can', 'this', 'that', 'these', 'those', 'a', 'an'];
  
  const words = text.toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .split(/\s+/)
    .filter(word => word.length > 2 && !commonWords.includes(word))
    .slice(0, 10);
  
  return words;
}

function extractJobTitle(text: string): string {
  // Try to extract job title from the text - look for common patterns
  const lines = text.split('\n').filter(line => line.trim().length > 0);
  
  // Look for lines that might be job titles (usually at the beginning)
  const titlePatterns = [
    /^(job title|position|role):\s*(.+)/i,
    /^(.+?)\s*-\s*(job|position|role)/i,
    /^([A-Z][A-Za-z\s]{5,50})$/,  // Capitalized phrase 5-50 chars
  ];
  
  for (const line of lines.slice(0, 5)) {  // Check first 5 lines
    for (const pattern of titlePatterns) {
      const match = line.match(pattern);
      if (match) {
        const title = match[2] || match[1];
        if (title && title.trim().length > 3) {
          return title.trim().slice(0, 100);  // Max 100 chars
        }
      }
    }
  }
  
  // Fallback: use first meaningful line
  const firstLine = lines[0]?.trim();
  if (firstLine && firstLine.length > 3 && firstLine.length < 100) {
    return firstLine;
  }
  
  return "Untitled Position";
}

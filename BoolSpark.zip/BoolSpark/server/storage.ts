import { 
  type BooleanString, 
  type InsertBooleanString,
  type SharedLink,
  type InsertSharedLink,
  type AnalyticsEvent,
  type InsertAnalyticsEvent,
  booleanStrings,
  sharedLinks,
  analyticsEvents
} from "@shared/schema";
import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import { desc, eq, count, sql } from "drizzle-orm";

export interface IStorage {
  // Boolean Strings (History)
  saveBooleanString(data: InsertBooleanString): Promise<BooleanString>;
  getBooleanStrings(limit?: number): Promise<BooleanString[]>;
  getBooleanStringById(id: number): Promise<BooleanString | undefined>;
  deleteBooleanString(id: number): Promise<void>;
  
  // Shared Links
  createSharedLink(data: InsertSharedLink): Promise<SharedLink>;
  getSharedLink(shareSlug: string): Promise<SharedLink | undefined>;
  incrementSharedLinkViews(shareSlug: string): Promise<void>;
  
  // Analytics
  trackEvent(data: InsertAnalyticsEvent): Promise<void>;
  getAnalytics(): Promise<{
    totalGenerations: number;
    recentEvents: AnalyticsEvent[];
  }>;
  getDailyUsage(days?: number): Promise<Array<{ date: string; count: number }>>;
  getFileTypeBreakdown(): Promise<Array<{ fileType: string; count: number }>>;
  getPopularSkills(): Promise<Array<{ skill: string; count: number }>>;
}

export class DbStorage implements IStorage {
  private db;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL environment variable is not set");
    }
    const sql = neon(process.env.DATABASE_URL);
    this.db = drizzle(sql);
  }

  async saveBooleanString(data: InsertBooleanString): Promise<BooleanString> {
    const [result] = await this.db.insert(booleanStrings).values(data).returning();
    return result;
  }

  async getBooleanStrings(limit: number = 50): Promise<BooleanString[]> {
    return await this.db
      .select()
      .from(booleanStrings)
      .orderBy(desc(booleanStrings.createdAt))
      .limit(limit);
  }

  async getBooleanStringById(id: number): Promise<BooleanString | undefined> {
    const [result] = await this.db
      .select()
      .from(booleanStrings)
      .where(eq(booleanStrings.id, id))
      .limit(1);
    return result;
  }

  async deleteBooleanString(id: number): Promise<void> {
    await this.db.delete(booleanStrings).where(eq(booleanStrings.id, id));
  }

  async createSharedLink(data: InsertSharedLink): Promise<SharedLink> {
    const [result] = await this.db.insert(sharedLinks).values(data).returning();
    return result;
  }

  async getSharedLink(shareSlug: string): Promise<SharedLink | undefined> {
    const [result] = await this.db
      .select()
      .from(sharedLinks)
      .where(eq(sharedLinks.shareSlug, shareSlug))
      .limit(1);
    
    return result;
  }

  async incrementSharedLinkViews(shareSlug: string): Promise<void> {
    await this.db
      .update(sharedLinks)
      .set({ viewCount: sql`${sharedLinks.viewCount} + 1` })
      .where(eq(sharedLinks.shareSlug, shareSlug));
  }

  async trackEvent(data: InsertAnalyticsEvent): Promise<void> {
    await this.db.insert(analyticsEvents).values(data);
  }

  async getAnalytics(): Promise<{ totalGenerations: number; recentEvents: AnalyticsEvent[] }> {
    const [countResult] = await this.db
      .select({ total: count() })
      .from(booleanStrings);
    
    const recentEvents = await this.db
      .select()
      .from(analyticsEvents)
      .orderBy(desc(analyticsEvents.createdAt))
      .limit(100);

    return {
      totalGenerations: countResult?.total || 0,
      recentEvents
    };
  }

  async getDailyUsage(days: number = 30): Promise<Array<{ date: string; count: number }>> {
    const result = await this.db
      .select({
        date: sql<string>`DATE(${booleanStrings.createdAt})`,
        count: count()
      })
      .from(booleanStrings)
      .where(sql`${booleanStrings.createdAt} >= NOW() - INTERVAL '${sql.raw(days.toString())} days'`)
      .groupBy(sql`DATE(${booleanStrings.createdAt})`)
      .orderBy(sql`DATE(${booleanStrings.createdAt})`);
    
    return result.map(row => ({ date: row.date, count: row.count }));
  }

  async getFileTypeBreakdown(): Promise<Array<{ fileType: string; count: number }>> {
    const result = await this.db
      .select({
        fileType: sql<string>`CASE WHEN ${booleanStrings.fileName} IS NULL THEN 'Text Input' ELSE UPPER(SUBSTRING(${booleanStrings.fileName} FROM '\\.([^.]+)$')) END`,
        count: count()
      })
      .from(booleanStrings)
      .groupBy(sql`CASE WHEN ${booleanStrings.fileName} IS NULL THEN 'Text Input' ELSE UPPER(SUBSTRING(${booleanStrings.fileName} FROM '\\.([^.]+)$')) END`)
      .orderBy(desc(count()));
    
    return result.map(row => ({ fileType: row.fileType || 'Unknown', count: row.count }));
  }

  async getPopularSkills(): Promise<Array<{ skill: string; count: number }>> {
    const allStrings = await this.db
      .select({ jobDescription: booleanStrings.jobDescription, jobTitle: booleanStrings.jobTitle })
      .from(booleanStrings)
      .limit(1000);
    
    const skillCounts: Record<string, number> = {};
    const commonSkills = [
      'React', 'Node.js', 'Python', 'Java', 'JavaScript', 'TypeScript', 'AWS', 'Docker', 'Kubernetes',
      'SQL', 'MongoDB', 'PostgreSQL', 'Git', 'Agile', 'Scrum', 'API', 'REST', 'GraphQL',
      'Vue', 'Angular', 'Express', 'Django', 'Flask', 'Spring', 'Laravel', 'Ruby', 'Rails',
      'Go', 'Golang', 'Rust', 'C++', 'C#', '.NET', 'Azure', 'GCP', 'CI/CD', 'DevOps',
      'Machine Learning', 'AI', 'TensorFlow', 'PyTorch', 'Data Science', 'Pandas', 'NumPy'
    ];
    
    for (const row of allStrings) {
      const text = `${row.jobTitle || ''} ${row.jobDescription}`.toLowerCase();
      for (const skill of commonSkills) {
        if (text.includes(skill.toLowerCase())) {
          skillCounts[skill] = (skillCounts[skill] || 0) + 1;
        }
      }
    }
    
    return Object.entries(skillCounts)
      .map(([skill, count]) => ({ skill, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 20);
  }
}

export const storage = new DbStorage();
